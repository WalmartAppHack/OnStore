package com.aryabhata.onstore.Beacon;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;

import com.aryabhata.onstore.R;

/**
 * Created by skaleem4 on 16-09-2015.
 */
public class Beacon extends Fragment {

    private Switch Easwitch;



    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.beacon, container, false);
        Easwitch = (Switch) rootView.findViewById(R.id.aaswitch);


        return rootView;
    }



}
