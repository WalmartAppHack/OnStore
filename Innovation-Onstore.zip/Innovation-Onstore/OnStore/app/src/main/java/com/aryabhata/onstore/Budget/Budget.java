package com.aryabhata.onstore.Budget;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;

import com.aryabhata.onstore.R;

/**
 * Created by skaleem4 on 16-09-2015.
 */
public class Budget extends Fragment {

    private SeekBar skbar;

    String url = "http://onstore-apphack.github.io/store_search/";

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.budget, container, false);
        skbar = (SeekBar) rootView.findViewById(R.id.skb);


        return rootView;
    }


}

