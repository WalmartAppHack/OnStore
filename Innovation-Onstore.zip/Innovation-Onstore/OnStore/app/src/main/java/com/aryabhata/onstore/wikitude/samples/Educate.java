package com.aryabhata.onstore.wikitude.samples;


import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.aryabhata.onstore.wikitude.samples.utils.urllauncher.ARchitectUrlLauncherActivity;


public class Educate extends ListActivity{

	//String classes[] ={"NXP","Cypress","xilinx"};
	String classes[] ={"List of Items :","Laptop","Fridge","IntelChip"};
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		String compareString = classes[position];
		//if(compareString.equals("NXP"))
		if(compareString.equals("Laptop"))
		{
			//String NXPurl = "http://goo.gl/QRx8wJ";
			String NXPurl = "http://retailaugmentedreality.github.io/laptop/";
			Intent NXP = new Intent(Educate.this,ARchitectUrlLauncherActivity.class);
			NXP.putExtra("needSent", NXPurl);
	    	startActivity(NXP);
		}
		//if(compareString.equals("Cypress"))
		if(compareString.equals("Fridge"))
		{
			//String Cypressurl = "http://goo.gl/FomdcC";
			String Cypressurl = "http://retailaugmentedreality.github.io/fridge/";
			Intent Cypress = new Intent(Educate.this,ARchitectUrlLauncherActivity.class);
			Cypress.putExtra("needSent", Cypressurl);
	    	startActivity(Cypress);
		}
		//if(compareString.equals("xilinx"))
		if(compareString.equals("IntelChip"))
		{
			//String xilinxsurl = "http://goo.gl/IGLTZN";
			String xilinxsurl = "http://retailaugmentedreality.github.io/IntelChip/";
			Intent xilinx = new Intent(Educate.this,ARchitectUrlLauncherActivity.class);
			xilinx.putExtra("needSent", xilinxsurl);
	    	startActivity(xilinx);
		}
		
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setListAdapter(new ArrayAdapter<String>(Educate.this, android.R.layout.simple_list_item_1,classes));
	}
}
