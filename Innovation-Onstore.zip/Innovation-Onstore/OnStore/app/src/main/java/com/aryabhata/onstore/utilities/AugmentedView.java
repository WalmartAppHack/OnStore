package com.aryabhata.onstore.utilities;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.aryabhata.onstore.R;
import com.aryabhata.onstore.wikitude.samples.utils.urllauncher.ARchitectUrlLauncherActivity;
import com.aryabhata.onstore.wikitude.samples.utils.urllauncher.ARchitectUrlLauncherCamActivity;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class AugmentedView extends ARchitectUrlLauncherActivity {

	@Override
	protected void onCreate( final Bundle savedInstanceState ) {
		super.onCreate( savedInstanceState );

		/* set content view to parent layout*/
		this.setContentView( R.layout.urllauncher_main );

		/* QR Code Decoder */
		Bundle bdl = getIntent().getExtras();
		String AugmentURL = bdl.getString("needSent");
		Toast.makeText(this.getApplicationContext(), "Scanned code " + AugmentURL, Toast.LENGTH_LONG).show();
		
		/* AR Launcher */
		AugmentedView.this.launchArchitectCam( AugmentURL );
		
		/* End - result = QA Quick Augmentation */
	}	
	

	@Override
	protected void onResume() {
		super.onResume();
	}
	

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}


	/**
	 * launches ARchitect Cam with given url
	 * @throws java.io.UnsupportedEncodingException
	 */
	private void launchArchitectCam( final String url ) {
		final Intent architectIntent = new Intent( this, ARchitectUrlLauncherCamActivity.class);
		
		try {
			final String encodedUrl = URLEncoder.encode( url, "UTF-8" );
			architectIntent.putExtra( ARchitectUrlLauncherCamActivity.ARCHITECT_ACTIVITY_EXTRA_KEY_URL, encodedUrl );
		} catch (UnsupportedEncodingException e) {
			Toast.makeText(this, "Unexpected Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
		AugmentedView.this.startActivity( architectIntent );
	}
}
