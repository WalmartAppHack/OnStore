package com.aryabhata.onstore.wikitude.samples;

import android.widget.Toast;

import com.aryabhata.onstore.R;
import com.aryabhata.onstore.wikitude.samples.utils.urllauncher.ARchitectUrlLauncherCamActivity;
import com.wikitude.architect.ArchitectView.ArchitectUrlListener;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;


public class SampleCamFragment extends AbstractArchitectCamFragmentV4{

	
	@Override
	public String getARchitectWorldPath() {
		try {
			final String decodedUrl = URLDecoder.decode(getActivity().getIntent().getExtras().getString(ARchitectUrlLauncherCamActivity.ARCHITECT_ACTIVITY_EXTRA_KEY_URL), "UTF-8");
			return decodedUrl;
		} catch (UnsupportedEncodingException e) {
			Toast.makeText(this.getActivity(), "Unexpected Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public int getContentViewId() {
		return R.layout.sample_cam;
	}

	@Override
	public int getArchitectViewId() {
		return R.id.architectView;
	}
	
	@Override
	public String getWikitudeSDKLicenseKey() {
		return WikitudeSDKConstants.WIKITUDE_SDK_KEY;
	}
	


	@Override
	public ArchitectUrlListener getUrlListener() {
		return new ArchitectUrlListener() {

			@Override
			public boolean urlWasInvoked(String uriString) {
				// by default: no action applied when url was invoked
				return false;
			}
		};
	}

}
